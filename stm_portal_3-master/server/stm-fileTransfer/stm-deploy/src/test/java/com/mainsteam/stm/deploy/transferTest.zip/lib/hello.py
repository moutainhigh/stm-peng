from PyQt4.QtDeclarative import QDeclarativeView
from PyQt4.QtGui import QApplication
from PyQt4.QtCore import QUrl

app = QApplication([])

view = QDeclarativeView()
rootContext = view.rootContext()
rootContext.setContextProperty("textData", "hi,i am heshengchao")
view.setSource(QUrl("test.qml"))
view.show()
app.exec_()