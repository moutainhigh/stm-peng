package com.chinawiserv.oc.util;

public class Nets {

	private String StartIP;
	private String EndIP;
	private String NetMask;

	public String getStartIP() {
		return StartIP;
	}

	public void setStartIP(String startIP) {
		StartIP = startIP;
	}

	public String getEndIP() {
		return EndIP;
	}

	public void setEndIP(String endIP) {
		EndIP = endIP;
	}

	public String getNetMask() {
		return NetMask;
	}

	public void setNetMask(String netMask) {
		NetMask = netMask;
	}
}
