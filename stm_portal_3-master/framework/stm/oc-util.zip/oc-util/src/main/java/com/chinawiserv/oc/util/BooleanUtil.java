package com.chinawiserv.oc.util;

public class BooleanUtil {

	public static boolean is(Boolean b) {
		if (b == null) {
			return false;
		}
		return b;
	}
}
