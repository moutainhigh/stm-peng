package com.chinawiserv.oc.util;

public enum OSEnum {
	Windows, MacOSX, Linux;
}
