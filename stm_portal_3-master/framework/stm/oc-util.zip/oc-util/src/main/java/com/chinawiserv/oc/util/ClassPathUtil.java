package com.chinawiserv.oc.util;

import java.io.File;

/**
 * <li>文件名称: ClassPathUtil.java</li>
 * <li>公　　司: 勤智数码科技股份有限公司</li>
 * <li>版权所有: 版权所有(C)2014-2020</li>
 * <li>修改记录: ...</li>
 * <li>内容摘要: ...</li>
 * <li>其他说明: ...</li>
 * @version  oc4.x
 * @since    2014年8月21日
 * @author   cwl
 */
public final class ClassPathUtil {
	
	private static final String tomcatHome=System.getProperties().getProperty("catalina.home")+File.separatorChar;
	
	private static final String commonClasses=tomcatHome+"common"+File.separatorChar+"classes"+File.separatorChar;

	/**
	 * 获取common下的资源文件类路径
	 * @return 形如 E:.../tomcat/common/classes/
	 */
	public static final String getCommonClasses(){
		return commonClasses;
	}
	
	/**
	 * 获取tomcat根路径
	 * @return 形如 E:.../tomcat/
	 */
	public static final String getTomcatHome(){
		return tomcatHome;
	}
}


